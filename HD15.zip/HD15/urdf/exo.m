in=1e-12;
en=1e-9;
R=1e3;
R1=50;
T=300;
R2=50e3;
kb=1.38064852e-23;
Sn=((in*R)^2+4*kb*T*R)*(R2/R1)^2;

vn=sqrt(Sn);